package com.example.wechat_clone_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
